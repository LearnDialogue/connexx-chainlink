# Cycling Matchmaker Server
To run, ensure you have the latest version of the `.env` file and run:

``` npm i && npm run start ```

To view the documentation:
``` magidoc generate && magidoc preview ```
